# files-preconfigured-phpmyadmin


## ENG DESCRIPTION
This script has been designed to complement a shell script made by me.

The script and these files were designed to quickly create a server in FiveM and automate the entire process.

The files it includes are:

  - /etc/apache2/conf-enabled/phpmyadmin.conf
  
  - /lib/systemd/system/fivem.service
  
  - /usr/bin/fivem_start.sh
  
  - /usr/share/phpmyadmin/config.inc.php


## ESP DESCRIPCIÓN
Este script ha sido diseñado para complementar a un shell script hecho por mi.

El script y estos archivos se diseñaron para crear un servidor en FiveM rápidamente y automatizar todo el proceso.

Los archivos que incluye son:

  - /etc/apache2/conf-enabled/phpmyadmin.conf
  
  - /lib/systemd/system/fivem.service
  
  - /usr/bin/fivem_start.sh
  
  - /usr/share/phpmyadmin/config.inc.php
  
  
  
  
  The script is not open to the public. SCRIPT NOT AVAILABLE
  
  El script no esta abierto al público. SCRIPT NO DISPONIBLE
